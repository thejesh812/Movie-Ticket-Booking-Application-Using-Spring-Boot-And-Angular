export class Scren {
  public screenId: number;
  public screenName: string;
  public rows: number;
  public columns: number;
}
