export class Customer {
  public customerId: number;
  public customerName: string;
  public email: string;
  public mobileNumber: string;
  public password: string;
  public address: string;
}
